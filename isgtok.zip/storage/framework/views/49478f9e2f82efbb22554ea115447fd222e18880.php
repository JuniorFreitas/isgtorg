<?php $__env->startSection('conteudo'); ?>
    <div class="well text-center">
        <h3>Seu curriculo foi cadastrado com sucesso! <br> Estaremos analisando, obrigado por se cadastrar.</h3>
        <a href="<?php echo e(route('trabalhe.index')); ?>" class="btn btn btn-success btn-info">Voltar</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('curriculo.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
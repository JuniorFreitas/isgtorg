<template>
    <h3>Teste</h3>
</template>

<script>
    export default {
        mounted() {
            console.log('Component ready.')
        }
    }
</script>

<?php $__env->startSection('conteudo'); ?>

    <div class="well text-center">
        <div class="alert alert-danger">
            <h3><?php echo e(($msg==404 ? "ERRO Tente novamente clique em voltar!" : "ERRO ao cadastrar! CPF ja em nossa base de dados")); ?></h3>
        </div>
        <a href="<?php echo e(route('trabalhe.index')); ?>" class="btn btn btn-success btn-info">Voltar</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('curriculo.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>